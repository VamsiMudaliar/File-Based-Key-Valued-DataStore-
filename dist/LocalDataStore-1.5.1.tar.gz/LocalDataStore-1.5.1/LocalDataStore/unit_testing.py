from . import DataStorageDB
import time
import os
'''

This file provides various testcases for our application to run


'''


app =DataStorageDB()











